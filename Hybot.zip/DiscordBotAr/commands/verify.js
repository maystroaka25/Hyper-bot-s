const { EmbedBuilder, ButtonBuilder, ButtonStyle, ActionRowBuilder } = require('discord.js');

module.exports = {
    name: 'verify',
    async execute(message) {
        const verifyEmbed = new EmbedBuilder()
            .setDescription('فعل نفسك من هنا من اجل الحصول على صلاحية الوصول للرومات')
            .setColor('#00ff00');
        
        const verifyButton = new ButtonBuilder()
            .setCustomId('verify')
            .setLabel('verify')
            .setStyle(ButtonStyle.Success);
        
        const row = new ActionRowBuilder()
            .addComponents(verifyButton);
        
        await message.channel.send({ embeds: [verifyEmbed], components: [row] });
    },
};
