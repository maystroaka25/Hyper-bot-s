const { EmbedBuilder } = require('discord.js');

module.exports = {
    name: 'help',
    async execute(message) {
        const helpEmbed = new EmbedBuilder()
            .setTitle('قائمة الأوامر')
            .setColor('#00ff00')
            .setDescription(`
                \`$help\` - عرض قائمة الأوامر
                \`$ping\` - عرض سرعة استجابة البوت
                \`$hello\` - رسالة ترحيبية
                \`$owner\` - معلومات عن منشئ البوت
                \`$send\` - إرسال رسالة للأعضاء
                \`$embed\` - تحويل النص إلى إمبد
                \`$verify\` - التحقق للحصول على صلاحيات
                \`خط\` - إظهار خط فاصل
            `);
        await message.channel.send({ embeds: [helpEmbed] });
    },
};
