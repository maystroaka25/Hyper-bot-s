const { Client, GatewayIntentBits, EmbedBuilder, PermissionsBitField, ActivityType } = require('discord.js');
require('dotenv').config();
const path = require('path');

let client;

function createClient() {
  client = new Client({
    intents: [
      GatewayIntentBits.Guilds,
      GatewayIntentBits.GuildMessages,
      GatewayIntentBits.MessageContent,
      GatewayIntentBits.GuildMembers,
    ]
  });

  const TARGET_CHANNEL = '1337775805069266974';
  const COMMAND_CHANNEL = '1336677649480814684';

  // دالة لإرسال رسالة $refresh
  async function sendRefreshMessage() {
    try {
      console.log('Attempting to send refresh message...');
      const channel = await client.channels.fetch(COMMAND_CHANNEL);
      if (channel) {
        await channel.send('$refresh');
        console.log('تم إرسال رسالة $refresh بنجاح');
      } else {
        console.error('Command channel not found');
      }
    } catch (error) {
      console.error('خطأ في إرسال رسالة $refresh:', error);
    }
  }

  client.once('ready', () => {
    console.log(`Logged in as ${client.user.tag}!`);
    client.user.setPresence({
      activities: [{ name: 'Hyper Gaming', type: ActivityType.Playing }],
      status: 'online'
    });

    // إرسال رسالة ✅ عند بدء تشغيل البوت
    client.channels.fetch(COMMAND_CHANNEL).then(channel => {
      if (channel) channel.send('✅');
    });

    console.log('Starting auto refresh feature...');

    // تشغيل الرسائل التلقائية بعد 5 ثواني من بدء البوت
    setTimeout(() => {
      console.log('Initial auto refresh delay completed, starting interval...');

      // إرسال أول رسالة
      sendRefreshMessage();

      // إنشاء مؤقت جديد لإرسال الرسائل كل دقيقة
      const refreshInterval = setInterval(sendRefreshMessage, 60000);

      // تخزين المؤقت في متغير عام للتنظيف لاحقًا
      client.refreshInterval = refreshInterval;

    }, 5000);
  });

  client.on('messageCreate', async message => {
    try {
      if (message.author.bot) return;

      // معالجة الأوامر للمشرفين فقط
      if (!message.member.permissions.has(PermissionsBitField.Flags.Administrator)) {
        // إذا كان في روم الطلبات، قم بتحويل الرسالة إلى embed فقط
        if (message.channel.id === TARGET_CHANNEL) {
          await message.delete();
          const embed = new EmbedBuilder()
            .setTitle('طلبات')
            .setDescription(message.content)
            .setColor('#9B59B6')
            .setTimestamp();
          await message.channel.send({ embeds: [embed] });
        }
        return;
      }

      // معالجة الأوامر
      if (message.content === '$help') {
        const helpEmbed = new EmbedBuilder()
          .setTitle('قائمة الأوامر المتاحة')
          .setDescription(`
**$embed** الرسالة
تحويل الرسالة إلى رسالة منسقة

**$send** الرسالة
إرسال رسالة إلى جميع أعضاء السيرفر في الخاص

**$restart**
إعادة تشغيل البوت

**$help**
عرض قائمة الأوامر المتاحة

ملاحظة: جميع الأوامر متاحة فقط للمشرفين.`)
          .setColor('#9B59B6')
          .setTimestamp();

        await message.channel.send({ embeds: [helpEmbed] });
        return;
      }

      if (message.content.startsWith('$send ')) {
        const text = message.content.slice(6);
        try {
          const guild = message.guild;
          const members = await guild.members.fetch();
          let successCount = 0;
          let failCount = 0;

          for (const [memberId, member] of members) {
            if (!member.user.bot) {
              try {
                await member.send(text);
                successCount++;
                // إضافة تأخير صغير بين الرسائل لتجنب التحديد
                await new Promise(resolve => setTimeout(resolve, 1000));
              } catch (err) {
                console.error(`Failed to send message to ${member.user.tag}: ${err.message}`);
                failCount++;
              }
            }
          }

          await message.channel.send(`تم إرسال الرسالة بنجاح إلى ${successCount} عضو.\nفشل الإرسال إلى ${failCount} عضو.`);
        } catch (error) {
          console.error('Error sending mass message:', error);
          await message.channel.send('حدث خطأ أثناء محاولة إرسال الرسائل.');
        }
        return;
      }

      if (message.content === '$restart') {
        // تنظيف المؤقت قبل إعادة التشغيل
        if (client.refreshInterval) {
          clearInterval(client.refreshInterval);
        }
        await message.channel.send('جاري إعادة تشغيل البوت...');
        await client.destroy();
        createClient();
        await client.login(process.env.DISCORD_TOKEN).then(() => {
          message.channel.send('✅');
        });
        return;
      }

      if (message.content.startsWith('$embed ')) {
        await message.delete();
        const content = message.content.slice(7);
        const embed = new EmbedBuilder()
          .setTitle(message.channel.id === TARGET_CHANNEL ? 'طلبات' : 'hyper')
          .setDescription(content)
          .setColor('#9B59B6')
          .setTimestamp();
        await message.channel.send({ embeds: [embed] });
      }

    } catch (error) {
      console.error('Error:', error);
    }
  });

  return client;
}

client = createClient();
client.login(process.env.DISCORD_TOKEN);