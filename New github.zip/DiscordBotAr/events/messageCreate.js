const { EmbedBuilder } = require('discord.js');
const config = require('../config');

module.exports = {
    name: 'messageCreate',
    async execute(message, client) {
        // تجاهل رسائل البوتات
        if (message.author.bot) return;

        // تحسين الأداء عن طريق التحقق من القناة أولاً
        if (message.channelId === config.AUTO_EMBED_CHANNEL_ID) {
            try {
                const embed = new EmbedBuilder()
                    .setDescription(message.content)
                    .setColor('#0099ff')
                    .setFooter({ text: message.author.tag });

                await message.delete();
                const embedMessage = await message.channel.send({ embeds: [embed] });
                await message.channel.send(config.LINE_IMAGE)
                    .catch(() => console.log('❌ تعذر إرسال الخط'));
                return;
            } catch (error) {
                console.error('❌ خطأ في معالجة الإمبد:', error);
                return;
            }
        }

        // معالجة الأوامر السريعة
        const quickCommands = {
            'hello': () => message.reply(`مرحباً ${message.author}`),
            'خط': () => message.channel.send(config.LINE_IMAGE)
        };

        const command = message.content.toLowerCase();
        if (quickCommands[command]) {
            try {
                await quickCommands[command]();
                return;
            } catch (error) {
                console.error(`❌ خطأ في تنفيذ الأمر السريع ${command}:`, error);
                return;
            }
        }

        // معالجة الأوامر مع البريفيكس
        const prefix = config.PREFIX.find(p => message.content.startsWith(p));
        if (!prefix) return;

        const args = message.content.slice(prefix.length).trim().split(/ +/);
        const commandName = args.shift().toLowerCase();

        const cmd = client.commands.get(commandName);
        if (!cmd) return;

        try {
            await cmd.execute(message, args);
        } catch (error) {
            console.error(`❌ خطأ في تنفيذ الأمر ${commandName}:`, error);
            await message.reply('حدث خطأ أثناء تنفيذ الأمر!').catch(() => {});
        }
    },
};