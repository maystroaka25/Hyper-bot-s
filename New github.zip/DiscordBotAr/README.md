# Discord Bot Deployment Guide

## Render.com Deployment
1. قم بزيارة [Render.com](https://render.com)
2. سجل باستخدام حساب GitHub
3. اختر "New +" ثم "Web Service"
4. حدد مستودع GitHub
5. أدخل الإعدادات التالية:
   - Name: discord-bot
   - Environment: Node
   - Build Command: npm install
   - Start Command: node index.js && node monitor.js && node keepalive.js
6. أضف متغير DISCORD_TOKEN في الإعدادات

## Railway.app Deployment
1. قم بزيارة [Railway.app](https://railway.app)
2. سجل باستخدام حساب GitHub
3. اختر "New Project"
4. حدد "Deploy from GitHub repo"
5. حدد المستودع
6. أضف متغير DISCORD_TOKEN في Variables
7. سيتم النشر تلقائياً

## Fly.io Deployment
1. قم بتثبيت [Fly CLI](https://fly.io/docs/hands-on/install-flyctl/)
2. سجل الدخول: `flyctl auth login`
3. في مجلد المشروع:
   ```bash
   flyctl launch
   flyctl secrets set DISCORD_TOKEN=your_token
   flyctl deploy
   ```

## Replit Deployment
البوت يعمل حالياً على Replit مع:
- نظام مراقبة تلقائي
- إعادة تشغيل عند التوقف
- فحص كل 30 ثانية

### ملاحظات هامة
- تأكد من إضافة DISCORD_TOKEN في كل منصة
- تجنب مشاركة التوكن في الكود
- استخدم المتغيرات البيئية دائماً
