const express = require('express');
const { exec } = require('child_process');

const app = express();
const PORT = 3002;

// تنفيذ run كل 30 ثانية في عملية منفصلة
const runBot = () => {
    console.log('🔄 بدء تشغيل البوت في عملية منفصلة...');

    // تشغيل البوت في عملية منفصلة
    const botProcess = exec('node index.js', (error, stdout, stderr) => {
        if (error) {
            console.error('❌ خطأ في تشغيل البوت:', error);
            return;
        }
        console.log('✅ تم تشغيل البوت بنجاح');
    });

    // تسجيل مخرجات البوت
    botProcess.stdout.on('data', (data) => {
        console.log(`📝 مخرجات البوت: ${data}`);
    });

    botProcess.stderr.on('data', (data) => {
        console.error(`❌ أخطاء البوت: ${data}`);
    });

    return botProcess;
};

let botProcess = null;

// جدولة تشغيل البوت كل 30 ثانية
const scheduleBot = () => {
    try {
        if (botProcess) {
            botProcess.kill();
        }
        botProcess = runBot();
    } catch (error) {
        console.error('❌ خطأ في جدولة البوت:', error);
    }
};

// تشغيل البوت لأول مرة
scheduleBot();

// جدولة إعادة التشغيل كل 30 ثانية
setInterval(scheduleBot, 30000);

// معالجة حالات التوقف غير المتوقع للمراقب نفسه
process.on('uncaughtException', (error) => {
    console.error('❌ خطأ غير متوقع في المراقب:', error);
    // إعادة تشغيل المراقب نفسه
    setTimeout(() => {
        console.log('🔄 إعادة تشغيل المراقب...');
        process.exit(1); // سيتم إعادة تشغيله تلقائياً بواسطة النظام
    }, 1000);
});

// تشغيل خادم المراقبة
app.listen(PORT, '0.0.0.0', () => {
    console.log(`🚀 خادم المراقبة يعمل على المنفذ ${PORT}`);
});

// معالجة إيقاف التشغيل بأمان
process.on('SIGTERM', () => {
    console.log('🛑 تم استلام إشارة إيقاف التشغيل. التنظيف...');
    if (botProcess) {
        botProcess.kill();
    }
    server.close(() => {
        console.log('✅ تم إغلاق خادم المراقبة');
        process.exit(0);
    });
});