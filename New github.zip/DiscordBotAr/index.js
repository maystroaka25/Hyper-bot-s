require('dotenv').config();
const { Client, GatewayIntentBits, Partials, Collection, Options, ActivityType } = require('discord.js');
const fs = require('fs');
const path = require('path');
const express = require('express');

// تحسين استهلاك الذاكرة
const client = new Client({
    intents: [
        GatewayIntentBits.Guilds,
        GatewayIntentBits.GuildMessages,
        GatewayIntentBits.MessageContent,
        GatewayIntentBits.DirectMessages
    ],
    partials: [Partials.Channel],
    makeCache: Options.cacheWithLimits({
        MessageManager: 5, 
        PresenceManager: 0,
        GuildMemberManager: 200,
        UserManager: 100,
        GuildManager: 5
    }),
});

client.commands = new Collection();

// إضافة خادم Express للتحقق من الصحة
const app = express();
const PORT = 3001;

// تحديث route الصحة لتتضمن حالة البث المباشر
app.get('/health', (req, res) => {
    try {
        if (client && client.ws.status === 0) {
            // التحقق من حالة البث المباشر
            const streaming = client.user.presence.activities.some(
                activity => activity.type === ActivityType.Streaming
            );

            res.json({ 
                status: 'ok', 
                ping: client.ws.ping,
                streaming: streaming
            });
        } else {
            res.json({ status: 'error', message: 'البوت غير متصل' });
        }
    } catch (error) {
        res.status(500).json({ status: 'error', error: error.message });
    }
});

// تأكد من أن الخادم يستمع على جميع الواجهات
const server = app.listen(PORT, '0.0.0.0', () => {
    console.log(`💓 خادم فحص الحالة يعمل على المنفذ ${PORT}`);
});

// تحميل الأوامر بشكل فعال
const loadCommands = () => {
    const commandsPath = path.join(__dirname, 'commands');
    const commandFiles = fs.readdirSync(commandsPath).filter(file => file.endsWith('.js'));

    for (const file of commandFiles) {
        try {
            const command = require(path.join(commandsPath, file));
            if (command.name) {
                client.commands.set(command.name, command);
                console.log(`✅ تم تحميل الأمر: ${command.name}`);
            }
        } catch (error) {
            console.error(`❌ خطأ في تحميل الأمر ${file}:`, error);
        }
    }
};

// تحميل الأحداث بشكل فعال
const loadEvents = () => {
    const eventsPath = path.join(__dirname, 'events');
    const eventFiles = fs.readdirSync(eventsPath).filter(file => file.endsWith('.js'));

    for (const file of eventFiles) {
        try {
            const event = require(path.join(eventsPath, file));
            if (event.name) {
                if (event.once) {
                    client.once(event.name, (...args) => event.execute(...args, client));
                } else {
                    client.on(event.name, (...args) => event.execute(...args, client));
                }
                console.log(`✅ تم تحميل الحدث: ${event.name}`);
            }
        } catch (error) {
            console.error(`❌ خطأ في تحميل الحدث ${file}:`, error);
        }
    }
};

console.log('🔄 جاري بدء تشغيل البوت...');
loadCommands();
loadEvents();

// معالجة الأخطاء بشكل أفضل
process.on('unhandledRejection', error => {
    console.error('❌ خطأ غير معالج:', error);
});

// تحسين معالجة الأخطاء والاتصال
client.on('error', error => {
    console.error('❌ خطأ في اتصال Discord:', error);
    // محاولة إعادة الاتصال تلقائياً
    setTimeout(() => {
        console.log('🔄 محاولة إعادة الاتصال...');
        client.login(process.env.DISCORD_TOKEN);
    }, 5000);
});

client.on('disconnect', () => {
    console.log('🔌 انقطع اتصال البوت. جاري إعادة المحاولة...');
    setTimeout(() => {
        console.log('🔄 محاولة إعادة الاتصال...');
        client.login(process.env.DISCORD_TOKEN);
    }, 5000);
});

client.on('reconnecting', () => {
    console.log('🔄 جاري إعادة الاتصال...');
});

// إضافة وظيفة تحديث حالة البث المباشر
function updateStreamingStatus() {
    try {
        client.user.setActivity("بث مباشر", {
            type: ActivityType.Streaming,
            url: "https://twitch.tv/yourchannel" // Replace with your actual stream URL
        });
        console.log('✅ تم تحديث حالة البث المباشر');
    } catch (error) {
        console.error('❌ خطأ في تحديث حالة البث:', error);
    }
}

// تحديث الحالة كل ساعة للتأكد من استمراريتها
setInterval(updateStreamingStatus, 3600000);


client.once('ready', () => {
    console.log(`✅ تم تسجيل دخول البوت بنجاح!`);
    console.log(`🤖 اسم البوت: ${client.user.tag}`);
    console.log(`📊 عدد السيرفرات: ${client.guilds.cache.size}`);

    // تعيين حالة البث المباشر عند بدء التشغيل
    updateStreamingStatus();
});

// Graceful shutdown
process.on('SIGTERM', () => {
    console.log('🛑 Received SIGTERM. Cleaning up...');
    server.close(() => {
        console.log('✅ HTTP server closed');
        client.destroy();
        process.exit(0);
    });
});

// مراقبة استهلاك الموارد
setInterval(() => {
    const used = process.memoryUsage();
    console.log('📊 استهلاك الموارد:');
    console.log(`- الذاكرة: ${Math.round(used.heapUsed / 1024 / 1024)}MB من أصل ${Math.round(used.heapTotal / 1024 / 1024)}MB`);
    console.log(`- RSS: ${Math.round(used.rss / 1024 / 1024)}MB`);
}, 900000); // كل 15 دقيقة

client.login(process.env.DISCORD_TOKEN)
    .then(() => {
        console.log('✅ تم تسجيل دخول البوت بنجاح!');
    })
    .catch(error => {
        console.error('❌ فشل تسجيل الدخول:', error);
        process.exit(1);
    });