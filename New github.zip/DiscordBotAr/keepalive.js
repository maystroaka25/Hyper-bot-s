const fetch = require('node-fetch');

// عنوان URL للبوت المحلي
const BOT_URL = 'http://0.0.0.0:3001/health';
const MONITOR_URL = 'http://0.0.0.0:3002/status';

async function keepAlive() {
    try {
        // فحص حالة البوت
        const botResponse = await fetch(BOT_URL);
        if (botResponse.ok) {
            const botData = await botResponse.json();
            console.log(`✅ ${new Date().toISOString()} - البوت يعمل`);
            console.log(`📊 حالة البوت: ${botData.status}, ping: ${botData.ping}ms`);

            // فحص حالة البث المباشر
            if (botData.streaming === false) {
                console.log('⚠️ حالة البث المباشر غير نشطة، جاري إعادة تفعيلها...');
                await fetch('http://0.0.0.0:3002/restart', { method: 'POST' });
            }
        } else {
            console.error(`⚠️ ${new Date().toISOString()} - البوت لا يستجيب:`, botResponse.status);
            await checkMonitorStatus();
        }
    } catch (error) {
        console.error(`❌ ${new Date().toISOString()} - خطأ في الاتصال بالبوت:`, error.message);
        await checkMonitorStatus();
    }
}

async function checkMonitorStatus() {
    try {
        const monitorResponse = await fetch(MONITOR_URL);
        if (monitorResponse.ok) {
            const monitorData = await monitorResponse.json();
            console.log('📊 حالة المراقب:', monitorData);

            if (!monitorData.status === 'online') {
                console.log('🔄 طلب إعادة تشغيل البوت من المراقب...');
                await fetch('http://0.0.0.0:3002/restart', { method: 'POST' });
            }
        }
    } catch (error) {
        console.error('❌ خطأ في الاتصال بخادم المراقبة:', error.message);
    }
}

// تشغيل الفحص كل 30 ثانية
const INTERVAL = 30000;
console.log(`🔄 بدء تشغيل برنامج المراقبة (الفحص كل ${INTERVAL/1000} ثانية)...`);

// التشغيل الأولي
keepAlive();

// جدولة عمليات الفحص المتكررة
setInterval(keepAlive, INTERVAL);

// معالجة إنهاء البرنامج بشكل نظيف
process.on('SIGINT', () => {
    console.log('\n👋 إيقاف برنامج المراقبة...');
    process.exit(0);
});

process.on('unhandledRejection', (reason, promise) => {
    console.error('❌ خطأ غير معالج:', reason);
});

// إضافة معالجة الأخطاء غير المتوقعة
process.on('uncaughtException', (error) => {
    console.error('❌ خطأ غير متوقع:', error);
    // إعادة تشغيل عملية المراقبة
    keepAlive();
});