const { EmbedBuilder } = require('discord.js');
const config = require('../config');

module.exports = {
    name: 'owner',
    async execute(message) {
        const ownerEmbed = new EmbedBuilder()
            .setTitle('Creator')
            .setColor('#00ff00')
            .setDescription(`Made by <@${config.OWNER_ID}>`);
        await message.channel.send({ embeds: [ownerEmbed] });
    },
};
