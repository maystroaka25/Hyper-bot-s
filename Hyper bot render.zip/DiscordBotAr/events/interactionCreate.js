const config = require('../config');

module.exports = {
    name: 'interactionCreate',
    async execute(interaction) {
        if (!interaction.isButton()) return;
        
        if (interaction.customId === 'verify') {
            try {
                const role = await interaction.guild.roles.fetch(config.VERIFY_ROLE_ID);
                if (role) {
                    await interaction.member.roles.add(role);
                    await interaction.reply({ content: 'تم التحقق بنجاح!', ephemeral: true });
                }
            } catch (error) {
                console.error('Error in verify button:', error);
                await interaction.reply({ content: 'حدث خطأ أثناء التحقق', ephemeral: true });
            }
        }
    },
};
