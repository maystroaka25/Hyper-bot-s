require('dotenv').config();
const { Client, GatewayIntentBits, Partials, Collection, Options } = require('discord.js');
const fs = require('fs');
const path = require('path');

// تحسين استهلاك الذاكرة
const client = new Client({
    intents: [
        GatewayIntentBits.Guilds,
        GatewayIntentBits.GuildMessages,
        GatewayIntentBits.MessageContent,
        GatewayIntentBits.DirectMessages
    ],
    partials: [Partials.Channel],
    makeCache: Options.cacheWithLimits({
        MessageManager: 5, // تخزين آخر 5 رسائل فقط
        PresenceManager: 0,
        GuildMemberManager: 200,
        UserManager: 100,
        GuildManager: 5
    }),
    sweepers: {
        messages: {
            interval: 1800, // تنظيف كل 30 دقيقة
            lifetime: 900  // حذف الرسائل بعد 15 دقيقة
        },
        users: {
            interval: 3600,
            filter: () => user => user.id !== client.user.id
        }
    }
});

client.commands = new Collection();

// تحميل الأوامر بشكل فعال
const loadCommands = () => {
    const commandsPath = path.join(__dirname, 'commands');
    const commandFiles = fs.readdirSync(commandsPath).filter(file => file.endsWith('.js'));

    for (const file of commandFiles) {
        try {
            const command = require(path.join(commandsPath, file));
            if (command.name) {
                client.commands.set(command.name, command);
                console.log(`✅ تم تحميل الأمر: ${command.name}`);
            }
        } catch (error) {
            console.error(`❌ خطأ في تحميل الأمر ${file}:`, error);
        }
    }
};

// تحميل الأحداث بشكل فعال
const loadEvents = () => {
    const eventsPath = path.join(__dirname, 'events');
    const eventFiles = fs.readdirSync(eventsPath).filter(file => file.endsWith('.js'));

    for (const file of eventFiles) {
        try {
            const event = require(path.join(eventsPath, file));
            if (event.name) {
                if (event.once) {
                    client.once(event.name, (...args) => event.execute(...args, client));
                } else {
                    client.on(event.name, (...args) => event.execute(...args, client));
                }
                console.log(`✅ تم تحميل الحدث: ${event.name}`);
            }
        } catch (error) {
            console.error(`❌ خطأ في تحميل الحدث ${file}:`, error);
        }
    }
};

console.log('🔄 جاري بدء تشغيل البوت...');
loadCommands();
loadEvents();

// معالجة الأخطاء بشكل أفضل
process.on('unhandledRejection', error => {
    console.error('❌ خطأ غير معالج:', error);
});

client.on('error', error => {
    console.error('❌ خطأ في اتصال Discord:', error);
});

client.on('disconnect', () => {
    console.log('🔌 انقطع اتصال البوت. جاري إعادة المحاولة...');
});

client.on('reconnecting', () => {
    console.log('🔄 جاري إعادة الاتصال...');
});

// تسجيل الدخول مع مراقبة الأداء
client.login(process.env.DISCORD_TOKEN)
    .then(() => {
        console.log('✅ تم تسجيل دخول البوت بنجاح!');
        console.log(`🤖 اسم البوت: ${client.user.tag}`);
        console.log(`📊 عدد السيرفرات: ${client.guilds.cache.size}`);
    })
    .catch(error => {
        console.error('❌ فشل تسجيل الدخول:', error);
        process.exit(1);
    });

// مراقبة استهلاك الموارد
setInterval(() => {
    const used = process.memoryUsage();
    console.log('📊 استهلاك الموارد:');
    console.log(`- الذاكرة: ${Math.round(used.heapUsed / 1024 / 1024)}MB من أصل ${Math.round(used.heapTotal / 1024 / 1024)}MB`);
    console.log(`- RSS: ${Math.round(used.rss / 1024 / 1024)}MB`);
}, 900000); // كل 15 دقيقة