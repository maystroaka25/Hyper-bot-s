module.exports = {
    name: 'ping',
    async execute(message) {
        const ping = Math.round(message.client.ws.ping);
        await message.reply(`🏓 Pong! Latency is ${ping}ms`);
    },
};
