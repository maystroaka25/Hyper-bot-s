const { EmbedBuilder } = require('discord.js');

module.exports = {
    name: 'embed',
    async execute(message, args) {
        if (args.length < 1) {
            await message.reply('الرجاء كتابة النص المراد تحويله');
            return;
        }

        const embedContent = args.join(' ');
        const blueEmbed = new EmbedBuilder()
            .setDescription(embedContent)
            .setColor('#0099ff');
        
        await message.channel.send({ embeds: [blueEmbed] });
    },
};
