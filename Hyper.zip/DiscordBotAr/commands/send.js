module.exports = {
    name: 'send',
    async execute(message, args) {
        if (args.length < 1) {
            await message.reply('الرجاء كتابة الرسالة المراد إرسالها');
            return;
        }

        const content = args.join(' ');

        try {
            if (message.mentions.users.size > 0) {
                message.mentions.users.forEach(async user => {
                    await user.send(`${content}\n${user}`);
                });
            } else if (message.mentions.roles.size > 0) {
                message.mentions.roles.forEach(role => {
                    role.members.forEach(async member => {
                        await member.send(`${content}\n${member}`);
                    });
                });
            } else {
                await message.guild.members.cache.forEach(async member => {
                    if (!member.user.bot) {
                        await member.send(content);
                    }
                });
            }
            await message.reply('تم إرسال الرسالة بنجاح!');
        } catch (error) {
            console.error('Error in send command:', error);
            await message.reply('حدث خطأ أثناء إرسال الرسائل');
        }
    },
};
